# Pagilist

Simple module to paginate lists using page or limit/offset. Source code available at
[Github](https://github.com/jersobh/pagilist).